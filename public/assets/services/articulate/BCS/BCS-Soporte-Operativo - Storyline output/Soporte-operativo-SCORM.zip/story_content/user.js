function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5tS5RdoYydI":
        Script1();
        break;
      case "6MLKYQUZSZ1":
        Script2();
        break;
      case "6Id9RsKkDyP":
        Script3();
        break;
      case "5XFIhn6KGvI":
        Script4();
        break;
      case "637fGi6SNjT":
        Script5();
        break;
      case "64AFvzjrsds":
        Script6();
        break;
      case "5fJMpYsWXec":
        Script7();
        break;
      case "5kZ64zqXMEj":
        Script8();
        break;
      case "5uhdYm5TjHm":
        Script9();
        break;
      case "6Goi988zBaJ":
        Script10();
        break;
      case "6kSTANPDWAw":
        Script11();
        break;
      case "5dChsYWAj8s":
        Script12();
        break;
      case "6pM2caRTxeE":
        Script13();
        break;
      case "5vTDZ9e0dNU":
        Script14();
        break;
      case "6OUTzsjhVbJ":
        Script15();
        break;
      case "5Y3Nt7M4FvZ":
        Script16();
        break;
      case "5bS0X3TwXc1":
        Script17();
        break;
      case "6KekoeDllua":
        Script18();
        break;
      case "61spNbQDtmu":
        Script19();
        break;
      case "67Ds1teEusS":
        Script20();
        break;
      case "5tpnmzMOmAr":
        Script21();
        break;
      case "5zYuFcTTCuA":
        Script22();
        break;
      case "5aVDIzEKVwN":
        Script23();
        break;
      case "6mtVOGAEh9D":
        Script24();
        break;
      case "6bnjcfAvubZ":
        Script25();
        break;
      case "6r7OWtpzW9m":
        Script26();
        break;
      case "6YoQFPqLlm7":
        Script27();
        break;
      case "67n6nZf4pBf":
        Script28();
        break;
      case "5vjGmmMaD84":
        Script29();
        break;
      case "5wqyQkvue3j":
        Script30();
        break;
      case "5bl8yTzPnwP":
        Script31();
        break;
      case "6dVjlUWNnKb":
        Script32();
        break;
      case "6Le1pkweeWS":
        Script33();
        break;
      case "6TlgHagsawH":
        Script34();
        break;
      case "6gjvwOPMbyF":
        Script35();
        break;
      case "6kCv2WSOQGf":
        Script36();
        break;
      case "6Yr0sAeadCw":
        Script37();
        break;
      case "6O1OhvlZ7cB":
        Script38();
        break;
      case "6NfnYVNtYVk":
        Script39();
        break;
      case "5ZgfwvTFaWP":
        Script40();
        break;
      case "6q5Imd1RnuV":
        Script41();
        break;
      case "6EoD4YBHsYc":
        Script42();
        break;
      case "6XtHWJniqjR":
        Script43();
        break;
      case "5ulqAAZ7jYt":
        Script44();
        break;
      case "62OWR4jqdDz":
        Script45();
        break;
      case "6GJmta6818U":
        Script46();
        break;
      case "5Zeqq2UiHNw":
        Script47();
        break;
      case "5eq3fbGq3tO":
        Script48();
        break;
      case "61vvkgbgXMM":
        Script49();
        break;
      case "5Zw9wLNt0ut":
        Script50();
        break;
      case "67CzflGH4Wt":
        Script51();
        break;
      case "6njIFaPmbg2":
        Script52();
        break;
      case "5gU4LuduEGE":
        Script53();
        break;
      case "633ILIGuhkQ":
        Script54();
        break;
      case "6KK15USgr4P":
        Script55();
        break;
      case "5pQrhzdOYcV":
        Script56();
        break;
      case "6AH3aTFPbGH":
        Script57();
        break;
      case "5kkhri0Rha9":
        Script58();
        break;
      case "65uOw39qSsK":
        Script59();
        break;
      case "6KfV0pQisO1":
        Script60();
        break;
      case "6oWIPLr0Tcy":
        Script61();
        break;
      case "6PMqfq21SvS":
        Script62();
        break;
      case "65g47AgIwYN":
        Script63();
        break;
      case "6WRe98ElnTb":
        Script64();
        break;
      case "5cHqvfFCmiI":
        Script65();
        break;
      case "5ypq3kiOU6a":
        Script66();
        break;
      case "5ahJ8I5VYN2":
        Script67();
        break;
      case "5jFgMnx1NsD":
        Script68();
        break;
      case "5YZ7ctRWa8J":
        Script69();
        break;
      case "66sZWJEpuAZ":
        Script70();
        break;
      case "68T0d1Z3NFr":
        Script71();
        break;
      case "6SzHzvfy1Ys":
        Script72();
        break;
      case "6TKzd0lsUMw":
        Script73();
        break;
      case "6aNP1wlvGEb":
        Script74();
        break;
      case "6dbz08XAaQl":
        Script75();
        break;
      case "6Bo9fa7BOmT":
        Script76();
        break;
      case "6Bl0cG1tJxN":
        Script77();
        break;
      case "6DckpfRDj7s":
        Script78();
        break;
      case "6DgYd9AxlKe":
        Script79();
        break;
      case "6RTBQVz8R2N":
        Script80();
        break;
  }
}

function Script1()
{
  console.log("hola mundo"); 
 document.body.style.backgroundImage = "url('bg.jpg')"; 
 document.body.style.backgroundSize = "cover"; 
 document.body.style.backgroundPosition = "center"; 
document.getElementsByClassName("area-primary")[0].style.padding = "0px"; 
document.getElementsByTagName("rect")[0].style.opacity = "0";

}

function Script2()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script3()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script4()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script5()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script6()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script7()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script8()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script9()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script10()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script11()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script12()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script13()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script14()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script15()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script16()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script17()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script18()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script19()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script20()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script21()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script22()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script23()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script24()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script25()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script26()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script27()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script28()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script29()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script30()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script31()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script32()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script33()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script34()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script35()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script36()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script37()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script38()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script39()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script40()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script41()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script42()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script43()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script44()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script45()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script46()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script47()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script48()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script49()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script50()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script51()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script52()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script53()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script54()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script55()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script56()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script57()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script58()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script59()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script60()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script61()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script62()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script63()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script64()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script65()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script66()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script67()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script68()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script69()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script70()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script71()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script72()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script73()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script74()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script75()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script76()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script77()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script78()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script79()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

function Script80()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 
}

