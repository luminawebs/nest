function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5afVYTcj8Wz":
        Script1();
        break;
      case "6WF1GCMXpTr":
        Script2();
        break;
      case "5rRmr89SP4j":
        Script3();
        break;
      case "5j4ruJshf89":
        Script4();
        break;
      case "6ltOCNapq2n":
        Script5();
        break;
      case "5ewsXuJNppw":
        Script6();
        break;
      case "6AY9Niz3nUT":
        Script7();
        break;
      case "5WRT7xDg6eF":
        Script8();
        break;
      case "67ETccr6S5a":
        Script9();
        break;
      case "6pN5iYfHjAV":
        Script10();
        break;
      case "5kXCf4pVan0":
        Script11();
        break;
      case "6AnAy8UB0iE":
        Script12();
        break;
      case "6N6hBVPOAme":
        Script13();
        break;
      case "6alNcpeX8S7":
        Script14();
        break;
      case "5zvDroIJixu":
        Script15();
        break;
      case "6GIfaRaN0af":
        Script16();
        break;
      case "5XVsRCRQ9Tj":
        Script17();
        break;
      case "6L0T5OJAjTt":
        Script18();
        break;
  }
}

function Script1()
{
  console.log("hola mundo"); 
 document.body.style.backgroundImage = "url('bg.jpg')"; 
 document.body.style.backgroundSize = "cover"; 
 document.body.style.backgroundPosition = "center"; 
document.getElementsByClassName("area-primary")[0].style.padding = "0px"; 
document.getElementsByTagName("rect")[0].style.opacity = "0";

}

function Script2()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script3()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script4()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script5()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script6()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script7()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script8()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script9()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script10()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script11()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script12()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script13()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script14()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script15()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script16()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script17()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

function Script18()
{
  document.getElementsByTagName("rect")[0].style.opacity = "0"; 

document.getElementsByClassName("body.is-mobile").style.background = "url('bg.jpg') !important"; 
}

